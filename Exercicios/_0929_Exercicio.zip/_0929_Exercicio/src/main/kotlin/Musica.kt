class Musica {
    var id:Int = 0
    var nome: String = ""
    var interprete: String = ""
    var acessosSpotify:Int = 0
    var acessoEncerrado: Boolean = false

}
